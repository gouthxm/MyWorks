//
//  Login.swift
//  democonsole
//
//  Created by Goutham Raj N on 19/04/22.
//

import Foundation


let database = Database()
let userInput = UserInput()

func register()  {
    let name = userInput.getName()
    let mobileNumber = userInput.getMobileNumber()
    let address = userInput.getAddress()
    let email = userInput.getEmail()
    let password = userInput.getPassword()
    let createStatementString = "INSERT INTO UserInput (Name, MobileNumber, Address, Email) VALUES ('\(name)', \(mobileNumber), '\(address)','\(email)','\(password)');"
    database.query(queryString: createStatementString)
    print("********************************************************")
    print("if you already have an account please choose login")
    userLogin()
}

func login() {
    let userName = userInput.getName()
    let userPassword = userInput.getPassword()
    
    let ball = "goutham"
    let pass = "all123"
    
    if userName == ball {
        if userPassword == pass {
            print("********************************************************")
            app.appliances()
        }
        else{
            print("wrong password")
            print("*****************")
        }
        return
    }
    else{
        print("wrong username")
        if userPassword != pass{
            print("wrong Password")
            print("*****************")
        }
    }
    

}
