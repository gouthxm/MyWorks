//
//  main.swift
//  democonsole
//
//  Created by Goutham Raj N on 07/04/22.
//

import Foundation
import SQLite3



let ac = ACService()
let wm = WashingService()
let fridge = FridgeService()
//new database
class Database {
    var db: OpaquePointer?
    var userList = [UserTable]()
    let dispatchQueue = DispatchQueue(label: "databaseQueue")
    let semaphore = DispatchSemaphore(value: 0)
    
    enum DBError: Error {
        case notCreate
        case connectionProblem
        case notPerpare
    }
    
    init() {
        dispatchQueue.async() {
            do {
                self.db = try self.openDatabase()
            } catch DBError.connectionProblem {
                print("Unable to open database.")
            }
            catch {
                print("Something went wrong!")
            }
            self.semaphore.signal()
        }
        semaphore.wait()
        
        dispatchQueue.async() {
            do {
                _ = try self.createTable()
            } catch DBError.notCreate {
                print("there is error in table creation")
            } catch DBError.notPerpare {
                print("\n CREATE TABLE statement is not prepared.")
            } catch {
                print("Something went wrong!")
            }
            self.semaphore.signal()
        }
        semaphore.wait()
    }
    
    func openDatabase() throws -> OpaquePointer? {
        let fileURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("mydatabsep.sqlite")
        if sqlite3_open(fileURL.path, &db) == SQLITE_OK {
            print("Successfully opened connection to database at \(fileURL.path)")
            return db
        }
        else {
            throw DBError.connectionProblem
        }
    }
    
    func createTable() throws {
        let createTableString = "CREATE TABLE IF NOT EXISTS UserInput(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT, mobileNumber INTEGER, adress varchar(80), email varchar(30), password varchar(30));"
        
        var createTableStatement: OpaquePointer?
        if sqlite3_prepare_v2(db, createTableString, -1, &createTableStatement, nil) ==
            SQLITE_OK {
            if sqlite3_step(createTableStatement) == SQLITE_DONE {
                print("\nTable User created.")
            } else {
                throw DBError.notCreate
            }
        } else {
            throw DBError.notPerpare
        }
        sqlite3_finalize(createTableStatement)
    }
    
    func query(queryString: String) {
        var statement: OpaquePointer?
        dispatchQueue.async {
            if sqlite3_prepare_v2(self.db, queryString, -1, &statement, nil) == SQLITE_OK {
                if sqlite3_step(statement) == SQLITE_DONE {
                    print("\n Your operation is successfully done.")
                } else {
                    print("\n Your operation is not done .")
                }
            } else {
                print("\n operation statement is not prepared")
            }
            sqlite3_finalize(statement)
            self.semaphore.signal()
        }
        semaphore.wait()
    }
    
    func read()  {
        userList = [UserTable]()
        let queryString = "SELECT * FROM User"
        var statement:OpaquePointer?
        dispatchQueue.async() {
            if sqlite3_prepare(self.db, queryString, -1, &statement, nil) == SQLITE_OK {
                while(sqlite3_step(statement) == SQLITE_ROW) {
                    let id = sqlite3_column_int (statement, 0)
                    let name = String(cString: sqlite3_column_text (statement, 1))
                    let mobilenumber = Int(sqlite3_column_int64 (statement, 2))
                    let address = String(cString: sqlite3_column_text (statement, 3))
                    self.userList.append(UserTable(id: Int(id), name: String(describing: name), mobilenumber: mobilenumber, address: String(describing: address)))
                }
            }
            self.semaphore.signal()
        }
        semaphore.wait()
    }
    
}




    

func userLogin(){

    print("please choose your choice")
            print(" 1.Login\n 2.Register\n ")
            print("*****************")

            if let operation = readLine() {
                switch operation {
                case "1":
                    login()
                case "2":
                    register()
                default:
                    print("You entered a wrong key")
                }
            }
    //login

}



//APPLIANCES
class Appliance{


func appliances(){

    print("These are the appliances we are servicing")
    print(" 1.A/C\n 2.Washing Machine\n 3.Fridge\n")
    print("********************************************************")
    if let operation = readLine() {
        switch operation {
        case "1":
            ac.getACList()
        case "2":
            wm.getWashingList()
        case "3":
            fridge.getFridgeList()

        default:
            print("You entered a wrong key,Please choose the correct option")
            print("********************************************************")
            appliances()
        }
        
    }



}
}

let app = Appliance()

//confirm function
func confirmService(){
print(" ********************************************************\n press 1 for choose the service\n press 2 to for get back to service list \n ********************************************************")
    if let operation = readLine() {
        switch operation {
        case "1":
            confirm()
        case "2":
            app.appliances()
        default:
            print("You entered a wrong key")
        }
    }
}
func confirm(){
    print("users adress")
    print(" 1.ASAP\n 2.SCHEDULE")
    if let operation = readLine() {
        switch operation {
        case "1":
            login()
        case "2":
            app.appliances()
        default:
            print("You entered a wrong key")
        }
    }
}


//Running


app.appliances()

//Database()

//run userLogin to run the code
//userLogin()





