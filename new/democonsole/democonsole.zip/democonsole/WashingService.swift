//
//  WashingService.swift
//  democonsole
//
//  Created by Goutham Raj N on 15/04/22.
//

import Foundation
class WashingService{
    
func getWashingList(){
    
    print("*****************")
    print("Washing Machine Service List")
    print(" 1.Repair\n 2.Top Load Service\n 3.Front Load Service\n 4. Full Service \n 5.Routine Service \n 6.Back")
    print("********************************************************")
    if let operation = readLine() {
        switch operation {
        case "1":
            washingRepair()
        case "2":
            topLoad()
        case "3":
            frontLoad()
        case "4":
            fullService()
        case "5":
            washingRoutine()
        case "6":
            print("******************************")
            app.appliances()
        default:
            print("You entered a wrong key,Please choose the correct option")
            print("********************************************************")
            getWashingList()
        }

    }

}

//WASHINGMACHINE SERVICE LIST

func washingRepair(){
    print("Full Repair(Top/Bottom)")
    print("description")
    print("*Price includes visits & diagnosis \n*Spare part rates applicable over per rate card")
    print("$160 \n60 min")
    print("Electrician's review")
}
func topLoad(){
    print("Top Load Repair")
    print("description")
    print("*Price includes visits & diagnosis \n*Spare part rates applicable over per rate card")
    print("$160 \n60 min")
    print("Electrician's review")
    
}
func frontLoad(){
    print("Front Load Repair")
    print("description")
    print("*Price includes visits & diagnosis \n*Spare part rates applicable over per rate card")
    print("$160 \n60 min")
    print("Electrician's review")
}
func fullService(){
    print("Full Service(Top/Bottom)")
    print("description")
    print("*Price includes visits & diagnosis \n*Spare part rates applicable over per rate card")
    print("$359 \n1hr 20min")
    print("Electrician's review")
}
func washingRoutine(){
    print("Routine Service(Top/Bottom)")
    print("description")
    print("*Price includes visits & diagnosis \n*Spare part rates applicable over per rate card")
    print("$200 \n60 min")
    print("Electrician's review")
}
}
