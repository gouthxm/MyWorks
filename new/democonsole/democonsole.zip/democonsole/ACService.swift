//
//  ACRepair.swift
//  democonsole
//
//  Created by Goutham Raj N on 15/04/22.
//

import Foundation
class ACService{
    func getACList(){

        print("*****************")
        print("A/C Service List")
        print(" 1.Repair\n 2.Installing\n 3.uninstalling\n 4.Installing and Uninstallaing\n 5.Routine Service \n 6.Back")
        print("********************************************************")
        if let operation = readLine() {
            switch operation {
            case "1":
                acRepair()
            case "2":
                acInstalling()
            case "3":
                acUninstalling()
            case "4":
                acInstallUninstall()
            case "5":
                acRoutine()
            case "6":
                print("*****************")
                app.appliances()
                
            default:
                print("You entered a wrong key,Please choose the correct option")
                print("********************************************************")
                getACList()
            }
        }

        
    }
    //AC SERVICE LIST

    func acRepair(){
        print("AC Repair(Window/Split)")
        print("description")
        print("*Accurate diagnosis & same day resolution after detailed inspection \n*Visit charges of $299 will be adjusted in the final bill")
        print("$299 \n45 min")
        print("Electrician's review")
        //testing
        confirmService()
    }

    func acInstalling(){
        print("Installation(Window/Split)")
        print("description")
        print("*Inspection of the AC, measurements of the respective wall followed by accuracy \n*Drilling wiring connections,installation of unit(s),pipe fixes")
        print("$799 \n1 hr 30 min")
        print("Electrician's review")
    }
    func acUninstalling(){
        print("Uninstallation(Window/Split)")
        print("description")
        print("*Detailed inspection of the AC for any kind of repairs,if needed \n*Closure of the pressure valves followed by proper storage of gas")
        print("$399 \n60 min")
        print("Electrician's review")
    }
    func acInstallUninstall(){
        print("Intallation and Uninstallation(Window/Split)")
        print("description")
        print("*Inspection of the AC, measurements of the respective wall followed by accuracy \n*Closure of the pressure valves followed by proper storage of gas")
        print("$1000 \n2 hr")
        print("Electrician's review")}
    func acRoutine(){
        print("AC Routine Service(Window/Split)")
        print("description")
        print("*Accurate diagnosis & same day resolution after detailed inspection \n*Visit charges of $299 will be adjusted in the final bill")
        print("$299\n45 min")
        print("Electrician's review")
        
    }
}
