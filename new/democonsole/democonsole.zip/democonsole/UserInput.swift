//
//  UserInput.swift
//  democonsole
//
//  Created by Goutham Raj N on 19/04/22.
//

import Foundation

class UserInput {
    
    func getName() -> String {
        print("*****************")
        print("Enter name")
        if let name = readLine() {
            return name
        }
        else {
            return ""
        }
    }
    
    func getMobileNumber() -> Int {
        var operation = true
        print("Enter mobile number")
        while operation {
            if let mobileNumber = readLine() {
                if mobileNumber.count == 10 {
                    if let mobileNumber = Int(mobileNumber) {
                        operation = false
                        return mobileNumber
                    }
                }
                else {
                    print("Please enter valid mobile number")
                    operation = true
                }
            }
        }
        return 0
    }
    
    func getAddress() -> String {
        print("Enter your address")
        if let address = readLine() {
            return address
        }
        return ""
    }

    
    
    
    func getId() -> Int {
        var operation = true
        print("enter id")
        while operation {
            if let id = readLine() {
                if let id = Int(id) {
                    operation = false
                    return id
                }
                else {
                    print("enter valid id")
                    operation = true
                }
            }
        }
        return 0
    }
    
    func getEmail() -> String{
        print("enter Email")
        if let email = readLine() {
            return email
        }
        return ""
    }
    
    func getPassword() -> String{
        print("enter a new password")
        if let password = readLine() {
            return password
        }
        return ""
    }
}




