//
//  FridgeService.swift
//  democonsole
//
//  Created by Goutham Raj N on 15/04/22.
//

import Foundation
class FridgeService{
    func getFridgeList(){
     
        print("*****************")
        print("Fridge Service List")
        print(" 1.Repair\n 2.Installing\n 3.uninstalling\n 4.Gas Filling\n 5.Routine Service \n 6.Back")
        print("********************************************************")
        if let operation = readLine() {
            switch operation {
            case "1":
                fridgeRepair()
            case "2":
                fridgeInstalling()
            case "3":
                fridgeUninstalling()
            case "4":
                gasFilling()
            case "5":
                fridgeRoutine()
            case "6":
                print("********************")
                app.appliances()
            default:
                print("*****************")
                print("You entered a wrong key,Please choose the correct option")
                print("********************************************************")
                getFridgeList()
            }
            /*
             acInstalling()
             acUninstalling()
             acInstallUninstall()
             acRoutine()
             washingRepair()
             topLoad()
             frontLoad()
             fullService()
             washingRoutine()
             fridgeRepair()
             fridgeInstalling()
             fridgeUninstalling()
             gasFilling()
             fridgeRoutine()
             */
        }


    }

    //FRIDGE SERVICE LIST


    func fridgeRepair(){
        print("Full Repair(Single/Double)")
        print("description")
        print(" *Price includes visit & Diagnosis \nSpare part rates applicable as per rate card")
        print("$160 \n60 min")
        print("Electrician's review")
    }
    func fridgeInstalling(){
        print("Installation(Single/Double)")
        print("description")
        print(" *Price includes visit & Diagnosis \nSpare part rates applicable as per rate card")
        print("$260 \n60 min")
        print("Electrician's review")
    }
    func fridgeUninstalling(){
        print("Uninstallation(Single/Double)")
        print("description")
        print(" *Price includes visit & Diagnosis \nSpare part rates applicable as per rate card")
        print("$190 \n60 min")
        print("Electrician's review")
    }
    func gasFilling(){
        print("Gas Filling(Single/Double)")
        print("description")
        print(" *Price includes visit & Diagnosis \nSpare part rates applicable as per rate card")
        print("$160 \n60 min")
        print("Electrician's review")
        
    }
    func fridgeRoutine(){
        print("Routine Service(Single/Double)")
        print("description")
        print(" *Price includes visit & Diagnosis \nSpare part rates applicable as per rate card")
        print("$160 \n60 min")
        print("Electrician's review")
        
    }
}
